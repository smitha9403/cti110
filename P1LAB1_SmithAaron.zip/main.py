def welcome_message():
    name = input()
    print("Hello " + name + " and welcome to CS Online!")

welcome_message()